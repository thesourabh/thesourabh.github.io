package sour.example.quikrcars.store;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Sourabh on 8/21/2015.
 */
public class CarsAdapter extends BaseAdapter implements Filterable {

    private Context context;
    private List<Car> carsList, orig;

    CarsAdapter(Context ctx, List<Car> list) {
        context = ctx;
        carsList = list;
    }

    @Override
    public int getCount() {
        return carsList.size();
    }

    @Override
    public Object getItem(int position) {
        return carsList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //Log.d(App.TAG, "position: " + position);
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row = inflater.inflate(R.layout.list_car, parent, false);
        TextView tvCarName = (TextView) row.findViewById(R.id.tvListCarName);
        TextView tvCarPrice = (TextView) row.findViewById(R.id.tvListCarPrice);
        Car car = carsList.get(position);
        tvCarName.setText(car.getName());
        row.setTag(car.getJson());
        String price = context.getResources().getString(R.string.rs) + " " + car.getPrice() + " L";
        tvCarPrice.setText(price);
        return row;
    }

    @Override
    public Filter getFilter() {
        return new Filter() {

            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                final FilterResults oReturn = new FilterResults();
                final ArrayList<Car> results = new ArrayList<Car>();
                if (orig == null)
                    orig = carsList;
                if (constraint != null) {
                    if (orig != null && orig.size() > 0) {
                        for (final Car g : orig) {
                            if (g.getName().toLowerCase()
                                    .contains(constraint.toString()))
                                results.add(g);
                        }
                    }
                    oReturn.values = results;
                }
                return oReturn;
            }

            @Override
            protected void publishResults(CharSequence constraint,
                                          FilterResults results) {
                carsList = (ArrayList<Car>) results.values;
                notifyDataSetChanged();
            }
        };
    }
}