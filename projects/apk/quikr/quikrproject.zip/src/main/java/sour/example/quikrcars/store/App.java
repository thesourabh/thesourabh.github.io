package sour.example.quikrcars.store;

/**
 * Created by Sourabh on 8/22/2015.
 */
public class App {
    public static final String TAG = "sour.example.quikrcars";
}
