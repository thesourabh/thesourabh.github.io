package sour.example.quikrcars.store;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;

import com.loopj.android.http.JsonHttpResponseHandler;

import org.apache.http.Header;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    private static final String TITLE = "Home";
    private ListView lvCars;
    private List<Car> carsList;
    private CarsAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        QuikrActionBar.setUp(this, TITLE);
        //setUpActionBar();

        carsList = new ArrayList<Car>();
        lvCars = (ListView) findViewById(R.id.lvCarsList);
        getCarsFromQuikr();
        lvCars.setOnItemClickListener(this);
        SearchView svSearch = (SearchView) findViewById(R.id.svSearch);
        svSearch.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return true;
            }
        });
    }

    private void setUpActionBar() {
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(false);
        actionBar.setDisplayShowTitleEnabled(false);
        LayoutInflater barInflater = LayoutInflater.from(this);
        View barView = barInflater.inflate(R.layout.action_bar, null);
        TextView tvActionBarTitle = (TextView) barView.findViewById(R.id.tvActionBarTitle);
        tvActionBarTitle.setText(TITLE);
        ActionBar.LayoutParams layoutParams = new ActionBar.LayoutParams(ActionBar.LayoutParams.MATCH_PARENT,
                ActionBar.LayoutParams.MATCH_PARENT);
        actionBar.setCustomView(barView, layoutParams);
        actionBar.setDisplayShowCustomEnabled(true);
        Toolbar parent = (Toolbar) barView.getParent();
        parent.setContentInsetsAbsolute(0, 0);
    }

    private void getCarsFromQuikr() {
        QuikrRestClient.get("api_hits", null, quikrHandler);
        QuikrRestClient.get("list_cars", null, quikrHandler);
    }

    private JsonHttpResponseHandler quikrHandler = new JsonHttpResponseHandler() {

        @Override
        public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
            Log.d(App.TAG, "onSuccess JSONObject");
            try {
                String hits = response.getString("api_hits");
                TextView tvApiHits = (TextView) findViewById(R.id.tvApiHits);
                tvApiHits.setText("No. of API hits: " + hits);
            } catch (JSONException jse) {
                Log.d(App.TAG, "Error in parsing received API hits JSON");
            }
        }

        @Override
        public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
            Log.d(App.TAG, "onSuccess JSONArray");
            try {
                for (int i = 0; i < response.length(); i++) {
                    JSONObject car = response.getJSONObject(i);
                    carsList.add(new Car(car));
                }
                TextView tvApiHits = (TextView) findViewById(R.id.tvNumCars);
                tvApiHits.setText("No. of API hits: " + response.length());
                Log.d(App.TAG, carsList.toString());
                adapter = new CarsAdapter(getBaseContext(), carsList);
                lvCars.setAdapter(adapter);
            } catch (JSONException je) {

            }
        }

        @Override
        public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject errorResponse) {
            Log.d(App.TAG, "onFailure JSONObject ");
        }
    };

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        // getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        JSONObject json = ((JSONObject) view.getTag());
        Intent intent = new Intent(MainActivity.this, DetailsActivity.class);
        intent.putExtra("car", json.toString());
        startActivity(intent);
    }
}
