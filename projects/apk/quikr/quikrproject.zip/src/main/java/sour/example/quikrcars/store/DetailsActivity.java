package sour.example.quikrcars.store;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.utils.PercentFormatter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class DetailsActivity extends AppCompatActivity {

    private static final String TITLE = "Car Details";
    private List<String> cityNames;
    private List<Integer> cityVals;
    private PieChart pie;
    private Car car;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        QuikrActionBar.setUp(this, TITLE);
        Bundle extras = getIntent().getExtras();
        JSONObject json = new JSONObject();
        String carString = extras.getString("car");
        try {
            json = new JSONObject(carString);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        car = new Car(json);
        TextView tvCarName = (TextView) findViewById(R.id.tvCarName);
        tvCarName.setText(car.getName());
        TextView tvCC = (TextView) findViewById(R.id.tvCC);
        tvCC.setText("CC: " + car.getCC());
        TextView tvType = (TextView) findViewById(R.id.tvType);
        tvType.setText("Type: " + car.getType());
        TextView tvAbs = (TextView) findViewById(R.id.tvAbs);
        tvAbs.setText("ABS: " + car.getAbs());
        TextView tvMileage = (TextView) findViewById(R.id.tvMileage);
        tvMileage.setText("Mileage: " + car.getMileage());
        TextView tvDesc = (TextView) findViewById(R.id.tvCarDesc);
        tvDesc.setText(car.getDescription());
        Button btnShare = (Button) findViewById(R.id.btnShare);
        btnShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_TEXT, car.getLink());
                intent.putExtra(android.content.Intent.EXTRA_SUBJECT, "QuikrCars");
                startActivity(Intent.createChooser(intent, "Share"));
            }
        });
        Button btnLink = (Button) findViewById(R.id.btnLink);
        btnLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(car.getLink()));
                startActivity(browserIntent);
            }
        });
        ImageView ivCarImage = (ImageView) findViewById(R.id.ivCarImage);
        new DownloadImageTask(ivCarImage).execute(car.getImage());
        pie = new PieChart(this);
        pie.setUsePercentValues(true);
        pie.setDescription("");
        LinearLayout llDetails = (LinearLayout) findViewById(R.id.llDetails);
        llDetails.addView(pie);
        cityNames = new ArrayList<String>();
        cityVals = new ArrayList<Integer>();
        try {
            JSONArray cities = json.getJSONArray("cities");
            for (int i = 0; i < cities.length(); i++) {
                JSONObject city = cities.getJSONObject(i);
                cityNames.add(city.getString("city"));
                cityVals.add(Integer.parseInt(city.getString("users")));
            }
            addData();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void addData() {
        pie.setDrawHoleEnabled(false);
        pie.setHoleColorTransparent(false);

        pie.setTransparentCircleColor(Color.WHITE);
        pie.setTransparentCircleAlpha(110);

        pie.setHoleRadius(58f);
        pie.setTransparentCircleRadius(61f);

        // enable rotation of the chart by touch
        pie.setRotationAngle(0);
        pie.setRotationEnabled(true);
        ArrayList<Entry> yVals1 = new ArrayList<Entry>();

        for (int i = 0; i < cityVals.size(); i++)
            yVals1.add(new Entry(cityVals.get(i), i));

        ArrayList<String> xVals = new ArrayList<String>();

        for (int i = 0; i < cityNames.size(); i++)
            xVals.add(cityNames.get(i));


        // create pie data set
        PieDataSet dataSet = new PieDataSet(yVals1, "");
        dataSet.setSliceSpace(3);
        dataSet.setSelectionShift(5);
        PieData data = new PieData(xVals, dataSet);
        data.setValueFormatter(new PercentFormatter());
        data.setValueTextSize(11f);
        data.setValueTextColor(Color.GRAY);

        pie.setData(data);

        // undo all highlights
        pie.highlightValues(null);

        // update pie chart
        pie.invalidate();

        Legend l = pie.getLegend();
        l.setPosition(Legend.LegendPosition.RIGHT_OF_CHART);
        l.setXEntrySpace(7f);
        l.setYEntrySpace(0f);
        l.setYOffset(0f);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        // getMenuInflater().inflate(R.menu.menu_details, menu);
        return true;
    }

    private void setUpActionBar() {
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(false);
        actionBar.setDisplayShowTitleEnabled(false);
        LayoutInflater barInflater = LayoutInflater.from(this);
        View barView = barInflater.inflate(R.layout.action_bar, null);
        TextView tvActionBarTitle = (TextView) barView.findViewById(R.id.tvActionBarTitle);
        tvActionBarTitle.setText(TITLE);
        ActionBar.LayoutParams layoutParams = new ActionBar.LayoutParams(ActionBar.LayoutParams.MATCH_PARENT,
                ActionBar.LayoutParams.MATCH_PARENT);
        actionBar.setCustomView(barView, layoutParams);
        actionBar.setDisplayShowCustomEnabled(true);
        Toolbar parent = (Toolbar) barView.getParent();
        parent.setContentInsetsAbsolute(0, 0);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        ImageView image;

        public DownloadImageTask(ImageView image) {
            this.image = image;
        }

        protected Bitmap doInBackground(String... urls) {
            String url = urls[0];
            Bitmap bitmap = null;
            try {
                InputStream in = new URL(url).openStream();
                bitmap = BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                Log.e(App.TAG, e.getMessage());
                e.printStackTrace();
            }
            return bitmap;
        }

        protected void onPostExecute(Bitmap result) {
            image.setImageBitmap(result);
        }
    }
}
