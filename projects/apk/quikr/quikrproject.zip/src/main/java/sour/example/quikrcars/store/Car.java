package sour.example.quikrcars.store;

import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by Sourabh on 8/22/2015.
 */
public class Car {
    private String name, price, image, cc, type, mileage, abs, desc, link;
    private JSONObject json;
    Car(JSONObject car) {
        try {
            name = car.getString("name");
            price = car.getString("price");
            image = car.getString("image");
            cc = car.getString("engine_cc");
            type = car.getString("type");
            mileage = car.getString("mileage");
            abs = car.getString("abs_exist");
            desc = car.getString("description");
            link = car.getString("link");
            json = car;
        } catch (JSONException jse) {
            Log.e(App.TAG, "JSON error");
        }
    }
    public String getName() {
        return name;
    }
    public String getPrice() {
        return price;
    }
    public String getCC() {
        return cc;
    }
    public String getType() {
        return type;
    }
    public String getMileage() {
        return mileage;
    }
    public String getAbs() {
        return abs;
    }
    public String getDescription() {
        return desc;
    }
    public String getLink() {
        return link;
    }
    public String getImage() {
        return image;
    }
    public JSONObject getJson() {
        return json;
    }
}