package sour.example.quikrcars.store;

import android.content.Context;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

/**
 * Created by Sourabh on 8/22/2015.
 */
public class QuikrActionBar {
    public static void setUp(AppCompatActivity context, String title) {
        ActionBar actionBar = context.getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(false);
        actionBar.setDisplayShowTitleEnabled(false);
        LayoutInflater barInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View barView = barInflater.inflate(R.layout.action_bar, null);
        TextView tvActionBarTitle = (TextView) barView.findViewById(R.id.tvActionBarTitle);
        tvActionBarTitle.setText(title);
        ActionBar.LayoutParams layoutParams = new ActionBar.LayoutParams(ActionBar.LayoutParams.MATCH_PARENT,
                ActionBar.LayoutParams.MATCH_PARENT);
        actionBar.setCustomView(barView, layoutParams);
        actionBar.setDisplayShowCustomEnabled(true);
        Toolbar parent = (Toolbar) barView.getParent();
        parent.setContentInsetsAbsolute(0, 0);
    }
}
